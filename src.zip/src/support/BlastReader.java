package support;

import java.io.IOException;









public interface BlastReader {


	public BlastIteration readIteration() throws IOException;
	public void close()throws IOException;
	
	
	
	
	
	
	
	
}
